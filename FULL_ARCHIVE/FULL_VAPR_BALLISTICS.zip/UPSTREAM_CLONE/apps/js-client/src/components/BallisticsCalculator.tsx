"use client";

import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ReferenceLine,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Crosshair, Target, Wind, Cloud, Settings, AlertCircle, Download } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ThemeToggle } from "@/components/theme-toggle";
import { toast } from "sonner";
import { useBallisticsCalculator } from "@/hooks/useBallisticsCalculator";
import type { CalculationResponse } from "@/lib/ballistics";

// ZOD Validation schema
const formSchema = z.object({
  weapon: z.object({
    sight_height: z.number().min(0.1).max(10.0),
    twist: z.number().min(1.0).max(50.0).optional(),
  }),
  ammo: z.object({
    bc: z.number().min(0.1).max(2.0),
    drag_model: z.enum(["G1", "G7"]),
    muzzle_velocity: z.number().min(500).max(5000),
    bullet_weight: z.number().min(20).max(1000).optional(),
  }),
  atmosphere: z.object({
    temperature: z.number().min(-50).max(150),
    pressure: z.number().min(20.0).max(35.0),
    humidity: z.number().min(0.0).max(1.0),
    altitude: z.number().min(0.0).max(20000),
  }),
  wind: z.object({
    speed: z.number().min(0.0).max(100.0),
    direction: z.number().min(1.0).max(12.0),
  }),
  zero_distance: z.number().min(25.0).max(500.0),
  max_range: z.number().min(100.0).max(3000.0),
  step_size: z.number().min(1.0).max(100.0),
});

type FormData = z.infer<typeof formSchema>;

export default function BallisticsCalculator() {
  const [results, setResults] = useState<CalculationResponse | null>(null);
  const [validationMessage, setValidationMessage] = useState<string | null>(null);
  const { calculate, validate, loading, error, resetError } = useBallisticsCalculator();
  const { theme } = useTheme();

  // Theme-aware chart colors for grid and axes
  const isDark = theme === "dark";
  const gridColor = isDark ? "#374151" : "#e5e7eb";
  const axisColor = isDark ? "#9ca3af" : "#6b7280";

  // Tooltip styles matching globals.css theme colors
  const tooltipStyle = {
    backgroundColor: isDark ? "#343434" : "#ffffff",
    border: isDark ? "1px solid rgba(255, 255, 255, 0.1)" : "1px solid #ebebeb",
    borderRadius: "8px",
    padding: "12px",
    boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
  };

  const tooltipItemStyle = {
    color: isDark ? "#fafafa" : "#252525",
  };

  const tooltipLabelStyle = {
    color: isDark ? "#fafafa" : "#252525",
    fontWeight: 600,
  };

  // Calculator form
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      weapon: {
        sight_height: 2.0,
        twist: 8.0,
      },
      ammo: {
        bc: 0.326,
        drag_model: "G7",
        muzzle_velocity: 2750,
        bullet_weight: 140,
      },
      atmosphere: {
        temperature: 88,
        pressure: 29.92,
        humidity: 0.7,
        altitude: 0,
      },
      wind: {
        speed: 5,
        direction: 3,
      },
      zero_distance: 100,
      max_range: 1000,
      step_size: 100,
    },
  });

  // Form submit actions
  const onSubmit = async (data: FormData) => {
    setValidationMessage(null);
    resetError();

    const validation = validate(data);
    if (!validation.valid) {
      setValidationMessage(validation.message);
      toast.error(validation.message);
      return;
    }

    try {
      const result = await calculate(data);
      setResults(result);
      toast.success("Calculation complete - Please open the Data tab to view results");
    } catch (err) {
      const message = err instanceof Error ? err.message : "An unexpected error occurred";
      setValidationMessage(message);
      toast.error(message);
    }
  };

  // Rechart data properties
  const formatChartData = () => {
    if (!results?.trajectory) return [];

    return results.trajectory.map((point) => ({
      distance: point.distance,
      drop: point.drop_adjustment,
      windage: point.windage_adjustment,
      velocity: point.velocity,
      energy: point.energy,
    }));
  };

  // Windage chart uses a top-down style: X = windage, Y = distance.
  const formatWindageChartData = () => {
    const data = [...formatChartData()].sort((a, b) => a.distance - b.distance);
    if (data.length === 0) return [];

    const startsAtOrigin = data[0].distance === 0 && data[0].windage === 0;
    if (startsAtOrigin) return data;

    return [{ ...data[0], distance: 0, windage: 0 }, ...data];
  };

  const getWindageDomainMax = () => {
    const chartData = formatWindageChartData();
    const maxAbsWindage = Math.max(...chartData.map((point) => Math.abs(point.windage)), 0);
    const paddedMax = maxAbsWindage + 3;
    return Math.ceil(paddedMax * 2) / 2;
  };

  const getWindageTicks = () => {
    const max = getWindageDomainMax();
    const ticks: number[] = [];

    for (let tick = -max; tick <= max + 0.0001; tick += 0.5) {
      ticks.push(Number(tick.toFixed(1)));
    }

    return ticks;
  };

  // Export trajectory data to CSV
  const exportToCSV = () => {
    if (!results?.trajectory) return;

    // CSV headers
    const headers = [
      "Distance (yd)",
      "Drop (mils)",
      "Windage (mils)",
      "Velocity (fps)",
      "Energy (ft-lb)",
      "Time (s)",
    ];

    // CSV rows
    const rows = results.trajectory.map((point) => {
      const absWindage = Math.abs(point.windage_adjustment);
      const windageDirection =
        point.windage_adjustment > 0 ? " R" : point.windage_adjustment < 0 ? " L" : "";
      const windageValue = absWindage === 0 ? "0" : `${absWindage.toFixed(2)}${windageDirection}`;

      return [
        point.distance.toFixed(0),
        point.drop_adjustment.toFixed(2),
        windageValue,
        point.velocity.toFixed(0),
        point.energy.toFixed(0),
        point.time.toFixed(3),
      ];
    });

    // Combine headers and rows
    const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");

    // Create blob and download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `ballistics_trajectory_${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success("Trajectory data exported to CSV");
  };

  return (
    <div className="bg-background min-h-screen p-4">
      <div className="mx-auto max-w-460">
        {/* Header with Theme Toggle */}
        <div className="mb-8 flex items-start justify-between">
          <header className="flex-1 text-center">
            <h1 className="text-foreground mb-2 text-4xl font-bold">
              VAPR Ballistics (Mil-based)
            </h1>
            <p className="text-muted-foreground">
              Advanced trajectory calculation with milliradian adjustments
            </p>
          </header>
          <div className="ml-4">
            <ThemeToggle />
          </div>
        </div>

        <Tabs defaultValue="inputs" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="inputs" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configuration
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center gap-2" disabled={!results}>
              <Target className="h-4 w-4" />
              Data
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inputs" className="space-y-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Weapon Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Crosshair className="h-5 w-5" />
                      Weapon Configuration
                    </CardTitle>
                    <CardDescription>Configure weapon-specific parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="weapon.sight_height"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sight Height (inches)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.1"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="weapon.twist"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Barrel Twist (inches)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.1"
                              {...field}
                              onChange={(e) =>
                                field.onChange(parseFloat(e.target.value) || undefined)
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Ammunition */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      Ammunition
                    </CardTitle>
                    <CardDescription>Configure ammunition parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="ammo.bc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ballistic Coefficient</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.001"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="ammo.drag_model"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Drag Model</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select drag model" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="G1">G1</SelectItem>
                              <SelectItem value="G7">G7</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="ammo.muzzle_velocity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Muzzle Velocity (fps)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="1"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="ammo.bullet_weight"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bullet Weight (grains)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="1"
                              {...field}
                              onChange={(e) =>
                                field.onChange(parseFloat(e.target.value) || undefined)
                              }
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Atmospheric Conditions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Cloud className="h-5 w-5" />
                      Atmospheric Conditions
                    </CardTitle>
                    <CardDescription>Configure environmental parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="atmosphere.temperature"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Temperature (°F)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="1"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="atmosphere.pressure"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Barometric Pressure (inHg)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="atmosphere.humidity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Humidity (0-1)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="atmosphere.altitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Altitude (feet)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="10"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Wind Conditions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Wind className="h-5 w-5" />
                      Wind Conditions
                    </CardTitle>
                    <CardDescription>Configure wind parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="wind.speed"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Wind Speed (mph)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="1"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="wind.direction"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Wind Direction (o&apos;clock)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.5"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Calculation Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Calculation Settings
                    </CardTitle>
                    <CardDescription>Configure calculation parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="zero_distance"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Zero Distance (yards)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="25"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="max_range"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Maximum Range (yards)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="50"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="step_size"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Step Size (yards)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="5"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {(validationMessage ?? error) && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{validationMessage ?? error}</AlertDescription>
                  </Alert>
                )}

                <div className="text-center">
                  <Button type="submit" disabled={loading} size="lg" className="px-8">
                    {loading ? "Calculating..." : "Calculate Trajectory"}
                  </Button>
                </div>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {results && (
              <>
                {/* Summary Cards */}
                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <p className="text-sm font-medium">Zero Adjustment</p>
                        <p className="text-2xl font-bold">
                          {results.zero_adjustment.toFixed(2)} Mils
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <p className="text-sm font-medium">Max Drop</p>
                        <p className="text-2xl font-bold">
                          {Math.max(
                            ...results.trajectory.map((p) => Math.abs(p.drop_adjustment))
                          ).toFixed(2)}{" "}
                          mils
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <p className="text-sm font-medium">Max Windage</p>
                        <p className="text-2xl font-bold">
                          {Math.max(
                            ...results.trajectory.map((p) => Math.abs(p.windage_adjustment))
                          ).toFixed(2)}{" "}
                          mils
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Trajectory Charts */}
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Elevation</CardTitle>
                      <CardDescription>
                        Bullet drop adjustment over distance
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={400}>
                        <LineChart
                          data={formatChartData()}
                          margin={{ top: 5, right: 30, left: 20, bottom: 70 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                          <XAxis
                            dataKey="distance"
                            label={{
                              value: "Distance (yards)",
                              position: "insideBottom",
                              offset: -10,
                              fill: axisColor,
                            }}
                            tick={{ fill: axisColor }}
                          />
                          <YAxis
                            label={{
                              value: "Drop (mils)",
                              angle: -90,
                              position: "insideLeft",
                              fill: axisColor,
                            }}
                            tick={{ fill: axisColor }}
                          />
                          <Tooltip
                            formatter={(value) => [Number(value).toFixed(2), "Drop (mils)"]}
                            contentStyle={tooltipStyle}
                            itemStyle={tooltipItemStyle}
                            labelStyle={tooltipLabelStyle}
                          />
                          <Line
                            type="monotone"
                            dataKey="drop"
                            stroke="var(--foreground)"
                            strokeWidth={2}
                            name="Drop (mils)"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Windage</CardTitle>
                      <CardDescription>
                        Wind drift view (X = windage, Y = distance)
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={400}>
                        <LineChart
                          data={formatWindageChartData()}
                          layout="vertical"
                          margin={{ top: 20, right: 30, left: 40, bottom: 40 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                          <ReferenceLine x={0} stroke={axisColor} strokeDasharray="4 4" />
                          <XAxis
                            type="number"
                            dataKey="windage"
                            domain={[-getWindageDomainMax(), getWindageDomainMax()]}
                            ticks={getWindageTicks()}
                            interval={0}
                            label={{
                              value: "Windage (mils)",
                              position: "insideBottom",
                              offset: -5,
                              fill: axisColor,
                            }}
                            tickFormatter={(value) => {
                              const absValue = Math.abs(value);
                              if (absValue === 0) return "0";
                              return value > 0
                                ? `${absValue.toFixed(1)} R`
                                : `${absValue.toFixed(1)} L`;
                            }}
                            tick={{ fill: axisColor }}
                          />
                          <YAxis
                            type="number"
                            dataKey="distance"
                            domain={[0, "dataMax"]}
                            reversed
                            label={{
                              value: "Distance (yards)",
                              angle: -90,
                              position: "insideLeft",
                              fill: axisColor,
                            }}
                            tick={{ fill: axisColor }}
                          />
                          <Tooltip
                            formatter={(value: number, _name, item) => {
                              const absValue = Math.abs(value);
                              const direction = value > 0 ? "R" : value < 0 ? "L" : "";
                              const windage =
                                absValue === 0 ? "0 mils" : `${absValue.toFixed(2)} mils ${direction}`;
                              return [windage, `Windage @ ${item.payload.distance.toFixed(0)} yd`];
                            }}
                            contentStyle={tooltipStyle}
                            itemStyle={tooltipItemStyle}
                            labelStyle={tooltipLabelStyle}
                          />
                          <Line
                            type="monotone"
                            dataKey="windage"
                            stroke="var(--foreground)"
                            strokeWidth={2}
                            name="Windage (mils)"
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                {/* Trajectory Table */}
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>Trajectory Table</CardTitle>
                        <CardDescription>
                          Detailed trajectory data points (Windage: R = Adjust Right, L = Adjust
                          Left to compensate for wind)
                        </CardDescription>
                      </div>
                      <Button
                        onClick={exportToCSV}
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Export CSV
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Distance</TableHead>
                            <TableHead>Drop (mils)</TableHead>
                            <TableHead>Windage (mils)</TableHead>
                            <TableHead>Velocity</TableHead>
                            <TableHead>Energy</TableHead>
                            <TableHead>Time</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {results.trajectory.map((point, index) => {
                            const absWindage = Math.abs(point.windage_adjustment);
                            const windageDirection =
                              point.windage_adjustment > 0
                                ? "R"
                                : point.windage_adjustment < 0
                                  ? "L"
                                  : "";
                            const windageDisplay =
                              absWindage === 0
                                ? "0 mils"
                                : `${absWindage.toFixed(2)} mils ${windageDirection}`;

                            return (
                              <TableRow key={index}>
                                <TableCell className="font-medium">
                                  {point.distance.toFixed(0)} yd
                                </TableCell>
                                <TableCell>{point.drop_adjustment.toFixed(2)} mils</TableCell>
                                <TableCell>{windageDisplay}</TableCell>
                                <TableCell>{point.velocity.toFixed(0)} fps</TableCell>
                                <TableCell>{point.energy.toFixed(0)} ft-lb</TableCell>
                                <TableCell>{point.time.toFixed(3)} s</TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
