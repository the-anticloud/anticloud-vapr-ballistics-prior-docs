# Technical Architecture — VAPR_BALLISTICS

**Upstream:** [https://github.com/robsdevcraft/vapr-ballistics](https://github.com/robsdevcraft/vapr-ballistics)
**License:** MIT
**Category:** ARTILLERY_MANUFACTURING
**Anticloud Integration:** PAX L5 Narrow L2 General 27B + AIOSS + Offline-First

## Upstream Description

Open-source ballistic calculator for precision rifles

## Anticloud Architectural Changes

1. PAX L5 Narrow L2 General 27B local ballistics modeling and tolerancing — air-gapped
2. AIOSS tamper-evident manufacturing log for every part (ITAR/EAR traceability)
3. AES-256 encryption for all design files and production records
4. Single-binary MES deployment on hardened manufacturing floor hardware
5. Zero-cloud: no design data leaves the secure facility
6. Offline quality control inference using local vision model
7. GPU/CPU equalizer: simulation runs on workstation GPU or CPU server
8. Open CLI replacing proprietary MES interfaces

## Integration Points

- **PAX Inference Socket:** Local HTTP endpoint at `127.0.0.1:11434/v1/chat` — same OpenAI-compatible API, zero cloud
- **AIOSS Hook:** Every write operation calls `aioss_append(event, payload)` before commit
- **Encryption Layer:** All file I/O routed through `anticloud_crypto.encrypt_at_rest()`
- **Single Binary Build:** `pyinstaller anticloud_vapr_ballistics.spec` or `go build -o vapr_ballistics`

## Deployment Modes

| Mode | Hardware | Notes |
| --- | --- | --- |
| Edge CPU | Raspberry Pi 4 / Intel NUC | Full feature set, PAX on CPU |
| Desktop GPU | RTX 3060 / A10 | PAX GPU inference, <1s latency |
| Server | 2× A100 | Full batch throughput |
| Air-gapped | Any x86/ARM | Zero network dependency |