# 02 Commitment To Society

**Project:** VAPR_BALLISTICS
**Upstream:** https://github.com/robsdevcraft/vapr-ballistics

Content specific to VAPR_BALLISTICS in category ARTILLERY_MANUFACTURING.
